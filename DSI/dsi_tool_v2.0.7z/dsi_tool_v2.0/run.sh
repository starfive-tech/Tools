#!/bin/bash

output=$1
if [ "$output" == "" ]; then
	output=output.txt
fi

./StarFive_DSI_Tool_v2.0.exe < input.md > ${output}
